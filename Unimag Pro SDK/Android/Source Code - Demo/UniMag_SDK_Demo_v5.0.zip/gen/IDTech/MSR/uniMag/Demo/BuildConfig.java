/** Automatically generated file. DO NOT MODIFY */
package IDTech.MSR.uniMag.Demo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}