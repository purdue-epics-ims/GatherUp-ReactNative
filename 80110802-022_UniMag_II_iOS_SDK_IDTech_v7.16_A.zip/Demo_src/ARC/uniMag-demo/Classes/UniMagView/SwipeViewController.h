
#import <UIKit/UIKit.h>

@interface SwipeViewController : UIViewController

@end
