
#import <UIKit/UIKit.h>

@interface AboutScreenViewController : UIViewController
@end
